// header files
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "common.h"

Rect makerect ( Point pt1, Point pt2) {
  Rect rct ;

  rct.pt1.x = ( pt1.x > pt2.x ) ? pt2.x : pt1.x  ;
  rct.pt1.y = ( pt1.y > pt2.y ) ? pt2.y : pt1.y  ;
  rct.pt2.x = ( pt1.x > pt2.x ) ? pt1.x : pt2.x  ;
  rct.pt2.y = ( pt1.y > pt2.y ) ? pt1.y : pt2.y  ;
  return rct ;

}

