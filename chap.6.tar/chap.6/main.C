//---------------
// header files
//---------------
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "common.h"

//------------
// main code
//------------
int main ( int argc, char **argv) {

  //-------------------
  // exit for teaching
  //-------------------
  printf("Exit for teaching!!! \n") ;
  exit(0) ;

  //---------------
  // structure (1)
  //---------------
  struct point pt ;
  pt.x = 1 ;
  pt.y = 2 ;

  printf("pt.x = %d, pt.y = %d\n", pt.x, pt.y ) ;

  //---------------
  // structure (2)
  //---------------
  struct point pt2 = { 1, 2} ;
  
  printf("pt2.x = %d, pt2.y = %d\n", pt2.x, pt2.y ) ;

  //---------------
  // structure (3)
  //---------------
  struct point pt3 ;

  pt3 = makepoint( 1, 2) ;

  printf("pt3.x = %d, pt3.y = %d\n", pt3.x, pt3.y ) ;

  //--------------------------
  // pointer to structure (4)
  //--------------------------
  struct point *ppt ;
  ppt = & pt3 ;
  
  printf("ppt->x = %d, ppt->y = %d\n", ppt->x, ppt->y ) ;
  printf("(*ppt).x = %d, (*ppt).y = %d\n", (*ppt).x, (*ppt).y ) ;

  //----------------
  // typedef struct
  //----------------
  Point pt4 = {3,4} ;
  Point pt5 = {5,6} ;
  Point pt6 ;

  pt6 = addpoint( pt4, pt5) ;

  printf("pt6.x = %d, pt6.y = %d\n", pt6.x, pt6.y ) ;

  //-------------------------
  // structure of structures
  //-------------------------
  Point pt7 = {3,7} ;
  Point pt8 = {5,4} ;
  Rect  rct ;

  rct = makerect( pt7, pt8) ;

  printf("rct.pt1=(%d,%d)  rct.pt2=(%d,%d)\n", 
	 rct.pt1.x, rct.pt1.y,
	 rct.pt2.x, rct.pt2.y ) ;

  //--------
  // sizeof
  //--------
  struct key keytab[3] = { {"auto", 0},
			  {"break", 1},
			  {"case", 2} } ;

  printf("sizeof(keytab) = %d\n", (int)sizeof(keytab) ) ;
  printf("sizeof(struct key) = %d\n", (int)sizeof( struct key) ) ;
  printf("sizeof(int) = %d\n", (int)sizeof( int) ) ;
  printf("sizeof(char *) = %d\n", (int)sizeof(char *) ) ;

  //-----------------------------
  // self referential structure
  //-----------------------------
  struct nametag first ;
  first.word = (char *)"Bush" ;
  first.count = 1 ;
  first.next = NULL ;

  struct nametag *nptr ;
  char *name = (char *)"Kerry" ;
  nptr = findnametag( &first, name) ;
  printf("nptr: word = %s, count=%d\n", nptr->word, nptr->count) ;

  name = (char *)"George" ;
  nptr = findnametag( &first, name) ;
  printf("nptr: word = %s, count=%d\n", nptr->word, nptr->count) ;

  name = (char *)"Washington" ;
  nptr = findnametag( &first, name) ;
  printf("nptr: word = %s, count=%d\n", nptr->word, nptr->count) ;

  name = (char *)"Bush" ;
  nptr = findnametag( &first, name) ;
  printf("nptr: word = %s, count=%d\n", nptr->word, nptr->count) ;

  name = (char *)"George" ;
  nptr = findnametag( &first, name) ;
  printf("nptr: word = %s, count=%d\n", nptr->word, nptr->count) ;

  //---------
  // union
  //---------
  union u_tag {
    unsigned int ival ;
    float  fval ;
  } u ;

  u.fval = 10.7 ;
  printf("u.ival = %x\n", u.ival) ;
  printf("u.fval = %f\n", u.fval) ;
  
  u.fval = 0 ;
  printf("u.ival = %x\n", u.ival) ;
  printf("u.fval = %f\n", u.fval) ;
  
  //----------
  // all done
  //----------
  exit(0) ; // for the lecture

} // main
