// header files
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "common.h"

struct point makepoint ( int x, int y) {
  struct point pt ;

  pt.x = x ;
  pt.y = y ;
  return pt ;

}

Point addpoint ( Point pt1, Point pt2) {
  Point pt ;

  pt.x = pt1.x + pt2.x ;
  pt.y = pt1.y + pt2.y ;
  return pt ;

}
