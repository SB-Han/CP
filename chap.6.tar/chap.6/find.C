// header files
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "common.h"

struct nametag *findnametag ( struct nametag *nptr, char *name) {

  if ( !strcmp(name, nptr->word) ) {
    return nptr ;
  } 
  else if ( (nptr->next) == NULL ) {
    nptr->next = (struct nametag *)malloc( sizeof( struct nametag)) ;
    (nptr->next)->word = name ;
    (nptr->next)->count = nptr->count + 1 ;
    (nptr->next)->next = NULL ;
    return (nptr->next) ;
  } 
  else {
    return findnametag( nptr->next, name) ; 
  }

}

