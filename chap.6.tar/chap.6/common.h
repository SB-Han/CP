//------------
// common.h
//------------

#ifndef COMMON_H
#define COMMON_H

// struct definitions
struct point {
  int x ;
  int y ;
} ;

typedef struct point Point ;

struct rect {
  struct point pt1 ;
  struct point pt2 ;
} ;

typedef struct rect Rect ;

struct key {
  char word[255] ;
  int count ;
} ;

struct nametag {
  char *word ;
  int count ;
  struct nametag *next ; // self reference
} ;


// external subroutines and functions
extern struct point makepoint( int , int ) ;
extern Point addpoint( Point , Point ) ;

extern Rect makerect( Point, Point) ;

extern struct nametag *findnametag( struct nametag *, char *ptr) ;

#endif
