#include <stdio.h>



int main(int argc, char **argv)
{
	int i;
	int sum = 0;
	
	printf("\nPROBLEM1\n");

/* problem 1, case1:for-loop */
	
	for ( i = 1 ; i < 10000 ; i += 1){
		if ( i % 16 == 7 ){
			sum += i;
			//printf("Sum = %5d\n", sum);
		}
	}
	printf("case1:for-loop     	Sum = %7d\n", sum);

/* problem 1, case2:while-loop */
	
	i = 1;
	sum = 0;
	while ( i < 10000 ){
		if ( i % 16 == 7){
			sum += i;
			//printf("%5d\n", sum);
		}
		i += 1;
	}
	printf("case2:while-loop   	Sum = %7d\n", sum);

/* problem 1, case3:do-while-loop */

	i = 1;
	sum = 0;
	do {
		if ( i % 16 == 7){
			sum += i;
		}
		i += 1;
	} while ( i < 10000 ) ;
	printf("case3:do-while-loop	Sum = %7d\n", sum);

/* problem 2, with continue */
	printf("\nPROBLEM2\n");
	
	sum = 0;
	for ( i = 1 ; i < 10000 ; i += 1){
		if ( i % 16 != 7)
			continue;
		sum += i;
	}
	printf("for-loop with continue  Sum = %7d\n", sum);
}
