#include <stdio.h>
#include <string.h>
#include <stdlib.h>


int main ( int argc, char **argv) {

  //-------------------
  // exit for teaching
  //-------------------
  printf("Exit for teaching! \n") ;
  exit(0) ;

  //--------------------
  // if, else if, else
  //--------------------
  int a = 37 ;
  // int a = 12 ;
  int b = 21 ;
  int c ;

  if ( a > b ) {
    c = a ;
  } else if ( a == b ) {
    c = 0 ;
  } else {
    c = b ;
  }
  printf("c = %d\n", c) ;

  //----------------------
  // switch, case, break
  //  a = 5 ;
  //----------------------
  a = 6 ;
  b = 7 ;

  switch (a) {
  case 1 :
  case 2 :
  case 3 :
    c = b - a ;
    break ; // break important
  case 4 :
  case 5 :
    c = b + a ;
    break ;
  case 6 :
  case 7 :
    c = b * a ;
    break ;
  default :
    c = 0 ;
    break ;
  }

  printf("c = %d\n", c) ;

  //----------
  // for-loop
  //----------
  int sum = 0 ;
  int i ;
  for ( i = 1 ; i <=10 ; i++ ) {
    sum += i ;
    printf("i=%5d  sum=%10d\n", i, sum) ;
  }
  printf( "for-loop: sum = %d\n", sum) ;

  //------------
  // while-loop
  //------------
  sum = 0 ;
  i = 1 ;
  while ( i <= 10 ) {
    //    sum += i ;
    //    i++ ;
    sum += i++ ;
  } 
  printf( "while-loop: sum = %d\n", sum) ;

  //----------
  // do-loop
  //----------
  sum = 0 ;
  i = 1 ;
  do {
    //    sum += i ;
    //    i++ ;
    sum += i++ ;
  } while ( i <= 10 ) ;
  printf( "do-loop: sum = %d\n", sum) ;

  //----------
  // continue
  //----------
  sum = 0 ;
  for ( i = 1 ; i < 10 ; i++ ) {
    if ( (i & 1) == 0 ) {  // if even number
      continue ; // skip
    }
    sum += i ;
  }
  printf( "sum = %d\n", sum) ;

  //----------
  // for-loop
  //----------
  sum = 0 ;
  for ( i = 1 ; i < 10 ; i += 2) {
    sum += i ;
  }
  printf( "sum = %d\n", sum) ;

  //---------
  // break
  //---------
  sum = 0 ;
  for ( i = 1 ; i < 100 ; i++) {
    sum += i ;
    if ( sum > 100 ) {
      printf("i = %d\n", i) ;
      break ;
    }
  }
  printf( "sum = %d \n", sum) ;

  //------
  // goto
  //------
  sum = 0 ;
  for ( i = 1 ; i < 100 ; i++) {
    sum += i ;
    if ( sum > 100 ) {
      printf("i = %d\n", i) ;
      goto out ;
    }
  }
  printf( "sum = %d\n", sum) ;

  //----------
  // All done
  //----------
  exit(0) ;

 out:
  printf( "out: i=%d, sum = %d\n", i, sum) ;
}
