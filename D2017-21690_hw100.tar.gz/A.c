#include"head.h"
void A(){
	printf("Celsius to Farenheit Table.\n");
	int max, min, step;
	float c, f;
	max=300;
	min=0;
	step=20;
	c=min;
	while(c<=max){
		f=c*(9.0/5.0)+32;
		printf ("%3.0f C\t --->\t %7.2f F\n",c ,f);
		c=c+step;
	}
}

