#include "head.h"
int main(void){
	A();
	return 0;
}

