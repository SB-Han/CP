#include <stdio.h>

/* HW1, Celsius to Farenheit */

int main(int argc, char **argv)
 {
 	int C;
	printf("Celsius to Fahrenheit table from 0 C to 300 C\n");
	for(C=0; C <= 300; C += 20)
		printf("%10d C \t --->\t  %6.2f F\n", C , (9.0*C/5.0)+32);	
 }
