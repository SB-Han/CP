// header files
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>

#include "common.h"

typedef struct userinfo {
  int  u_id ;
  unsigned long  ssn ;
} user_info ;

//------------
// main code
//------------
int main ( int argc, char **argv) {

  //-------------------
  // exit for teaching
  //-------------------
  fprintf( stderr, "Exit for teaching!!!\n") ;
  exit(0) ;
  
  //---------------------
  // set the random seed
  //---------------------
  unsigned int seed = 123456 ;
  srand( seed) ;

  //-------------------------------
  // define a pointer of user_info
  //-------------------------------
  user_info *ui_p ;

  //----------------------------------
  // allocate memory for the pointer
  //----------------------------------
  int num_of_user = 100 ;
  ui_p = (user_info *)malloc( num_of_user * sizeof( user_info) ) ;

  //-----------------------------------
  // set the ssn using random numbers.
  //-----------------------------------
  for (int i = 0 ; i < num_of_user ; i++) {
    user_info *tmp_p = ui_p + i;
    tmp_p->u_id = i ; // set id
    tmp_p->ssn = rand() ; // set ssn
  }

  //---------------------
  // print the 33rd data
  //---------------------
  int id = 33 ;
  user_info *tmp_p = ui_p + id ;
  fprintf( stdout, "33rd user id = %d\n", tmp_p->u_id) ;
  fprintf( stdout, "33rd user ssn = %ld\n", tmp_p->ssn) ;

  //----------------------------
  // write the data into a file
  //----------------------------
  FILE *f_p ;
  char filename[255] = "zion" ;
  if ( ( f_p = fopen( filename, "w")) == NULL ) {
    fprintf( stderr, "error: fopen failed\n") ;
    exit(10) ;
  }
  int num_fw = fwrite( ui_p, sizeof( user_info), num_of_user, f_p) ;
  if (num_fw != num_of_user) {
    fprintf( stderr, "error: fwrite failed\n") ;
    exit(11) ;    
  }
  fclose( f_p) ;

  //---------------------------------------------------------------
  // Since the data is stored in a file, we may release the memory.
  //---------------------------------------------------------------
  free( ui_p) ;

  //--------------------------------------------------
  // we want to read only the 33rd data from the file
  //--------------------------------------------------
  FILE *fp ;
  if ( ( fp = fopen( filename, "r")) == NULL ) {
    fprintf( stderr, "error: fopen failed\n") ;
    exit(12) ;
  }
  //---------------------------------------------------
  // we want to set the file pointer to the 33rd data
  // using random access function: fseek().
  //---------------------------------------------------
  long  offset = id * sizeof( user_info) ; // the unit is bytes
  int err = fseek( fp, offset, SEEK_SET) ; // random access
  if (err) {
    fprintf( stderr, "error: fseek failed\n") ;
    exit(13) ;
  }
  //---------------------
  // read in the data
  //---------------------
  user_info  u_tmp ;
  int num_fr = fread( &u_tmp, sizeof( user_info), 1, fp) ;
  if (num_fr != 1){
    fprintf( stderr, "error: fread failed\n") ;
    exit(14) ;    
  }

  fclose( fp) ;

  //----------------
  // print the data
  //----------------
  fprintf( stdout, "user id = %d\n", u_tmp.u_id) ;
  fprintf( stdout, "user ssn = %ld\n", u_tmp.ssn) ;

  //----------
  // all done
  //----------
} // main
