// header files
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>

#include "common.h"

// main code
double average ( int count, ... ) {
  double total = 0 ;
  va_list list ;

  va_start( list, count) ;

  for ( int i = 1 ; i <= count ; i++ ) {
    total += va_arg(list, double) ;
  }

  va_end(list) ;

  return (total / count) ;

} // main
