//------------
// common.h
//------------

#ifndef COMMON_H
#define COMMON_H

// external subroutines and functions
extern double average( int , ... ) ;


#endif
