// header files
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>

#include "common.h"

//-----------
// main code
//-----------
int main ( int argc, char **argv) {

  //--------------------
  // Exit for teaching
  //--------------------
  printf("Exit for teaching!!! \n") ;
  exit(0) ;

  //--------------------------
  // conversion specification
  //--------------------------
  char str[100] = "hello, world";
  
  printf("s       = :%s:\n", str) ;
  printf("10s     = :%10s:\n", str) ;
  printf(".10s    = :%.10s:\n", str) ;
  printf("-10s    = :%-10s:\n", str) ;
  printf("15s     = :%15s:\n", str) ;
  printf(".15s    = :%.15s:\n", str) ;
  printf("-15s    = :%-15s:\n", str) ;
  printf("15.10s  = :%15.10s:\n", str) ;
  printf("-15.10s = :%-15.10s:\n", str) ;

  //------------
  // usage of *
  //------------
  double f = 1.234567890987654321 ;
  for (int i = 1 ; i < 15 ; i++ ) {
    printf("prec = %5d  f = %+.*f\n", i, i, f) ;
  }

  //--------------------------------------------------
  // variable-length argument list ---> flexible code
  //--------------------------------------------------
  double d1 = 37.5 ;
  double d2 = 22.5 ;
  double d3 = 1.7 ;
  double d4 = 10.2 ;
  double avg ;

  avg = average(2, d1, d2) ;
  printf("avg(d1,d2) = %f\n", avg) ;
  
  avg = average(3, d1, d2, d3) ;
  printf("avg(d1,d2,d3) = %f\n", avg) ;
  
  avg = average(4, d1, d2, d3, d4) ;
  printf("avg(d1,d2,d3,d4) = %f\n", avg) ;
  
  //-------------------------
  // formatted input - scanf
  //-------------------------
  char fname[255], lname[255] ;

  //  printf("enter <first name> <last name>\n") ;
  //  scanf("%s %s", fname, lname) ;
  //  printf("name = %s %s\n", fname, lname) ;

  //-------------------------
  // formatted input - scanf
  //-------------------------
  int month, day, year ;
  //  printf("enter <Date of Birth mm/dd/yyyy (example 12/23/2003)>\n") ;
  //  scanf("%d/%d/%d", &month, &day, &year) ;
  //  printf("date of birth = Year:%d Month:%d Day:%d\n", year, month, day) ;

  //-----------------------
  // File Access - reading
  //-----------------------
  FILE *fp ;
  fp = fopen("input", "r") ;
  char dummy[255] ;
  fscanf( fp, "%s %s %s", dummy, fname, lname) ;  
  fscanf( fp, "%s %s %s %d/%d/%d", dummy, dummy, dummy, &month, &day, &year) ;
  
  printf("name = %s %s  date of birth = Year:%d Month:%d Day:%d\n",
	 fname, lname, year, month, day) ;

  fclose( fp) ;

  //-----------------------
  // File Access - writing
  //-----------------------
  fp = fopen("output", "w") ;
  fprintf( fp, "name = %s %s\n", lname, fname) ;
  fprintf( fp, "date of birth = year: %d month: %d day: %d\n",
	   year, month, day) ;
  fclose( fp) ;

  //-----------------------
  // stdout, stdin, stderr
  //-----------------------
  fprintf( stdout, "Hello, Sim!\n") ; // printf
  fprintf( stderr, "Error message: This is for teaching.\n") ;

  //-----------------------
  // Line input and output
  //-----------------------
  fp = fopen("input", "r") ;
  char line[500] ;
  fgets( line, 255, fp) ; // fortran read
  sscanf( line, "%s %s", dummy, fname) ;
  fclose( fp) ;

  fp = fopen("output.2", "w") ;
  sprintf( line, "first name = %s\n", fname) ;
  fputs( line, fp) ; // fortran write
  fclose(fp) ;

  //------------------------
  // Unix Command execution
  //------------------------
  system("date") ;
  system("ls -l") ;
  system("cal") ;

  //-----------------
  // random number ;
  //-----------------
  unsigned int seed = 123456 ;
  srand( seed) ; // set the seed

  printf("RAND_MAX = %d\n", RAND_MAX ) ;
  for (int i = 0 ; i < 10 ; i++ ) {
    printf("%3d: rand = %d\n", i, rand() ) ;
  }

  printf("=== reset the random seed\n") ;
  srand( seed) ; // set the seed
  for (int i = 0 ; i < 10 ; i++ ) {
    printf("%3d: rand = %d\n", i, rand() ) ;
  }

  //-----------
  // all done
  //-----------
  exit(0) ;

} // main
