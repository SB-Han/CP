//---------------
// header files
//---------------
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

//#include "common.h"
#include <common.h>

//---------------------------------------------------
// external variables, public variables (definition)
//---------------------------------------------------
int ea, eb, ec ; // external var


int main ( int argc, char **argv) {

  //-------------------
  // Exit for teaching
  //-------------------
  printf("Exit for teaching!!! \n") ;
  exit(0) ;

  //------------------------------------
  // internal call of the function fx()
  //------------------------------------
  int a = 7 ; // local var
  int b = 5 ;
  int c ;
  int fx( int, int) ; // fx declaration
  
  c = fx( a, b) ; // call fx
  printf("fx: a, b = %d, %d\n", a, b) ;
  printf("fx: c = %d\n", c) ;

  //------------------------------------
  // external call of the function fy()
  //------------------------------------
  c = fy( a, b) ;
  printf("fy: c = %d\n", c) ;

  //-------------------
  // exteral variables
  //-------------------
  ea = a ;
  eb = b ;
  fz() ; // call the function fz()
  printf("ea = %d  eb=%d\n", ea, eb) ;
  printf("fz: ec = %d\n", ec) ;

  //--------------------------------------
  // external call of the function fxy()
  //--------------------------------------
  c = fxy( a, b) ;
  printf("fxy: c = %d\n", c) ;

  //--------------------------------------
  // external call of the function fxy()
  //--------------------------------------
  c = fxy( a, b) ;
  printf("fxy: c = %d\n", c) ;

  //--------------------------------------
  // external call of the function fxy()
  //--------------------------------------
  c = fxy( a, b) ;
  printf("fxy: c = %d\n", c) ;

  //----------------------------------------
  // recursive call of the function recur()
  // calculate factorial of a number
  //----------------------------------------
  a = 5 ;
  b = 1 ;
  c = recur( a, b) ; // c = a!
  printf("recur: c = %d! = %d\n", a, c) ;

  //----------
  // all done
  //----------
  exit(0) ;

}

//----------------------------
// local function definition
//----------------------------
int fx( int x, int y) {
  int z ;
  z = (MX * x + y) / DX ;
  x++ ; // dummy
  y-- ; // dummy
  return z ;
}
