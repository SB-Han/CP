// header files
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <common.h>

int fy( int a, int b) {
  int c ;
  c = (MX * a + b) / DX ;
  a++ ;
  b-- ;
  return c ;
}
