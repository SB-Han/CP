// header files
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "common.h"

static int count = 0 ; // static variables 

int fxy( int a, int b) {
  int c ;
  c = (MX * a + b) / DX ;
  count++ ;
  printf("fxy: count = %d\n", count) ;
  return c ;
}
