//------------
// common.h
//------------

#ifndef COMMON_H
#define COMMON_H



#if defined(MKS)

#define MX  31
#define DX  13

#elif defined(CGS)

#define MX  37
#define DX  17

#else

#define MX  1
#define DX  1

#endif


// external variables (declare)
extern int ea, eb, ec ;

// external subroutines and functions
extern int  fxy( int, int) ; // function declaration
extern int  fy ( int, int) ; // function declaration
extern void fz() ; // function declaration
extern int  recur( int, int) ; // function declaration


#endif
