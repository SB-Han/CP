// header files
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "common.h"

static int fact = 1 ; // static variables 

// recursion: a!
int recur( int a, int b) {
  // initialize
  if (b == 1 ) {
    fact = b ;
  }
  // calculate the factorial
  if (b < a) {
    fact *= b++ ;
    recur( a, b) ; // recursive function call
  } else if (b == a) {
    fact *= b ;
  } else {
    printf("recur: somthing is wrong!!!") ;
    exit(11) ; 
  }
  return fact ;
}
