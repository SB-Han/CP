// header files
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "common.h"

void fz() {
  ec = (MX * ea + eb) / DX ;
  ea++ ;
  eb-- ;
}
