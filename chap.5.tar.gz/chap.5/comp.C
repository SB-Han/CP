// header files
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "common.h"

void comp( char *xp, char *yp, int (*cal)(int, int)) {
  int x, y ;
  int z ;
  x = atoi(xp) ;
  y = atoi(yp) ;

  z = (*cal)( x, y) ;
  printf("comp(%d,%d) = %d\n", x, y, z) ;
}

int add( int x, int y) {
  return (x+y) ;
}

int sub( int x, int y) {
  return (x-y) ;
}
