//------------
// common.h
//------------

#ifndef COMMON_H
#define COMMON_H


// external subroutines and functions
extern void swap_1(int , int ) ; // function declaration
extern void swap_2(int *, int *) ; // function declaration
extern void error_exit( int) ;

extern void comp( char *, char *, int (*cal)(int, int) ) ;
extern int add( int, int) ;
extern int sub( int, int) ;

#endif
