// header files
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "common.h"

void error_exit( int argc) {
  printf("Error: argc = %d is not equal to 3*x+1\n", argc) ;
  exit(argc) ;
}

