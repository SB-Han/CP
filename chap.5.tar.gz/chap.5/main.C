// header files
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include <common.h>

//-----------
// main code
//-----------
int main ( int argc, char **argv) {
  int x = 1 ;
  int y = 2 ;
  int *ip ; // interger pointer

  //-------------------
  // Exit for teaching
  //-------------------
  printf("Exit for teaching \n") ;
  exit(0) ;

  //---------------------
  // pointer example (1)
  //---------------------
  ip = &x ;
  printf("ip = %p\n", ip) ; // address
  printf("*ip = %d\n", *ip) ; // contents

  //---------------------
  // pointer example (2)
  //---------------------
  ip = &y ;
  printf("ip = %p\n", ip) ; // address
  printf("*ip = %d\n", *ip) ; // contents

  //---------------------------
  // pointer example (3) array
  //---------------------------
  //  int z[5] = {5,11,12,23,35} ; // array
  int z[] = {5,11,12,23,35} ; // array

  //  ip = &z[0] ;
  ip = z ;
  printf("ip = %p\n", ip) ; // address
  printf("*ip = %d\n", *ip) ; // z[0]
  printf("(ip+3) = %p\n", (ip+3)) ; // &z[3]
  printf("*(ip+3) = %d\n", *(ip+3)) ; // z[3]
  printf("ip[3] = %d\n", ip[3]) ; // z[3]

  //---------------------
  // pointer example (4)
  //---------------------
  ip = z ;
  printf("ip = %lx\n", (unsigned long)ip) ; // casting
  printf("ip+2 = %lx\n", (unsigned long)(ip+2)) ;
  printf("ip[2] = %d\n", ip[2]) ;

  //---------------------
  // pointer example (5)
  //---------------------
  ip = z ;
  printf("*++ip = %d\n", *++ip) ; // ip[1] = z[1]
  ip = z ;
  printf("++*ip = %d\n", ++*ip) ; // z[0]+1

  //---------------------------------
  // pointers and function arguments
  // pass by value
  //---------------------------------
  printf("=== pass by value === wrong exmaple\n") ;
  int a = 7 ;
  int b = 5 ;

  swap_1( a, b) ;

  printf("a = %d\n", a) ;
  printf("b = %d\n", b) ;

  //-----------------
  // pass by pointer
  //-----------------
  printf("=== pass by pointer === correct example\n") ;
  swap_2( &a, &b) ;

  printf("a = %d\n", a) ;
  printf("b = %d\n", b) ;

  //----------------------------------------
  // memory allocation example (1) malloc()
  //----------------------------------------
  int c[10] = {0,1,2,3,4,5,6,7,6,9} ; // memory allocation for arrays.
  int size = 10 * sizeof(int) ;
  int *cp = NULL ;

  printf("size = %d \n", size) ;
  printf("cp = %p before allocation\n", cp) ; 

  cp = (int *)malloc( size) ; // allocate memory to pointer cp
  printf("cp = %p after allocation\n", cp) ; 

  printf("initial cp[7] = %d\n", cp[7]) ;

  for (int i = 0 ; i < 10 ; i++ ) {
    *(cp+i) = i ; // cp[i]
  }

  printf("final cp[7] = %d\n", cp[7]) ;
  printf("c[7] = %d\n", c[7]) ;

  free(cp) ; // free the memory

  //----------------------------------------
  // memory allocation example (2) calloc()
  //----------------------------------------
  int n = 10 ; // number of integer in the array

  cp = (int *)calloc( n, sizeof( int)) ; // allocate memory to pointer cp
  printf("cp = %p after allocation\n", cp) ; 

  printf("initial cp[5] = %d\n", cp[5]) ;

  for (int i = 0 ; i < 10 ; i++ ) {
    *(cp+i) = i ; // cp[i]
  }

  printf("final cp[5] = %d\n", cp[5]) ;
  printf("c[5] = %d\n", c[5]) ;

  free(cp) ; // free the memory

  //----------------------------------
  // character pointers and functions
  //----------------------------------
  char *chp ;
  chp = (char *)"now is the time" ;
  
  printf("chp = %p, chp = %s, chp[9] = %c\n", chp, chp, chp[9]) ;

  //----------------------------------
  // character pointers and functions
  //----------------------------------
  char pm[255] ;
  sprintf( pm, "now is the time") ;

  printf("pm = %p, pm = %s, pm[9] = %c\n", pm, pm, pm[9]) ;

  //-----------------------------------------
  // pointer arrays and pointers to pointers
  //-----------------------------------------
  char mptr[4][255] = { "Void", "January", "February", "March" } ;

  printf("mptr[1] = %s\n", mptr[1]) ;
  printf("mptr[3] = %s\n", mptr[3]) ;

  //--------------------------------------------------
  // multi-dimensional array (1) stack memory example
  //--------------------------------------------------
  int twod[3][3] = { { 11, 23, 43},
		     { 65, 72, 81},
		     { 93, 87, 73} } ;

  printf("twod = %p \n", twod) ;
  printf("array   ---> twod[1][2] = %d\n",twod[1][2]) ;
  printf("pointer ---> *(*(twod+1)+2) = %d\n",*(*(twod+1)+2)) ;
  
  //--------------------------------------------------
  // multi-dimensional array (2) data memory example
  //--------------------------------------------------
  int **twod_p ; // pointer to the pointer to integer
  n = 3 ; // number of array elements

  twod_p = (int **)malloc( n * sizeof( int *) ) ;
  printf( "twod_p = %p \n", twod_p) ;
  for (int i = 0 ; i < n ; i++) {
    twod_p[i] = (int *)calloc( n, sizeof( int) ) ;
    printf( "twod_p[%d] = %p \n", i, twod_p[i]) ;
  }
  
  for (int i = 0 ; i < n ; i++)
    for (int j = 0 ; j < n ; j++){
      twod_p[i][j] = i * 10 + j ;
  }
  
  printf("array   ---> twod_p[1][2] = %d\n",twod_p[1][2]) ;
  printf("pointer ---> *(*(twod_p+1)+2) = %d\n",*(*(twod_p+1)+2)) ;

  //------------------------
  // command line arguments
  //------------------------
  int i = 0 ;

  printf("argv[0] = %s\n", argv[i++]) ;

  if ( (argc/3 == 0) || (argc%3 != 1) ) {
    error_exit(argc) ;
  }

  while (i < argc) {
    if (!strcmp(argv[i],"-a")) {
      int x, y ;
      x = atoi(argv[++i]) ;
      y = atoi(argv[++i]) ;
      printf("x+y = %d + %d = %d\n", x, y, x+y) ; 
    } else if (!strcmp(argv[i],"-s")) {
      int x, y ;
      x = atoi(argv[++i]) ;
      y = atoi(argv[++i]) ;
      printf("x-y = %d - %d = %d\n", x, y, x-y) ; 
    } else {
      printf("Error: unknown flag\n") ;
      exit(99) ;
    }

    i++ ;
  } // while

  //------------------------------------------------------
  // implement the same thing using pointer to function.
  //------------------------------------------------------
  i = 1 ;
  while (i < argc) {    

    if (!strcmp(argv[i],"-a")) {
      comp(argv[i+1], argv[i+2], add) ;
    } else if (!strcmp(argv[i],"-s")) {
      comp(argv[i+1], argv[i+2], sub) ;
    } else {
      printf("Error: unknown flag\n") ;
      exit(99) ;
    }

    i += 3 ;
  }

  //----------
  // all done
  //----------
  exit(0) ; // for the lecture

} // main
