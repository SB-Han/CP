// header files
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "common.h"

void swap_1( int x, int y) {
  int z ;
  z = x ;
  x = y ;
  y = z ;
}

void swap_2( int *xp, int *yp) {
  int z ;
  z = *xp ;
  *xp = *yp ;
  *yp = z ;
}
